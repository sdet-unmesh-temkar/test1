package testRunner;

import generalutilities.ReportAndLogging;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

import java.io.File;


@RunWith(Cucumber.class)
@CucumberOptions(
        features = {"src/test/resources/featureFiles"},
        tags = "@test",
        glue = {"stepDefinitions","stepUtils"},
        plugin = {"pretty", "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:", "json:target/cucumber.json", "formatter.XraySyncUtil","formatter.InterframeworkListener"},
        monochrome = true)

public class TestRunner {
    static {
        String pathToLogbackXML =
                System.getProperty("user.dir") + File.separator
                        + "src" + File.separator
                        + "test" + File.separator
                        + "resources" + File.separator;

        System.setProperty("logback.configurationFile", pathToLogbackXML);
    }

    @BeforeClass
    public static void beforeClass() {
        System.setProperty("jdk.tls.client.protocols", "TLSv1.2");
        if (System.getProperty("env") == null) {
            System.setProperty("env", "E2E");
        }
        System.out.println("env:     " + System.getProperty("env"));
    }

    @AfterClass
    public static void writeExtentReport() {
        System.out.println("env:     from runner after class " + System.getProperty("env"));
        ReportAndLogging reportAndLogging = new ReportAndLogging();
        reportAndLogging.copyReport();
    }

}