@SpartanSanity
Feature: Spartan sanity

  @SOLTESAU-28153
  Scenario: Verify login to AgentDesktop
    This is sample scenario description
    Given AgentDesktop Solstice Login Application
      | Username              | Password              | Environment                  |
      | AGENTDESKTOP/Username | AGENTDESKTOP/Password | AGENTDESKTOP/testEnvironment |
    Given AgentDesktop Solstice Login Application
      | Username              | Password              | Environment                  |
      | AGENTDESKTOP/Username | AGENTDESKTOP/Password | AGENTDESKTOP/testEnvironment |

  @SOLTESAU-28156
  Scenario: Verify AgentDesktop login & close browser functionality
    Given AgentDesktop Solstice Login Application
      | Username              | Password              | Environment                  |
      | AGENTDESKTOP/Username | AGENTDESKTOP/Password | AGENTDESKTOP/testEnvironment |
    And Close browser

  @SOLTESAU-28157
  Scenario: Verify AgentDesktop autheticate functionality
    Given AgentDesktop Solstice Login Application
      | Username              | Password              | Environment                  |
      | AGENTDESKTOP/Username | AGENTDESKTOP/Password | AGENTDESKTOP/testEnvironment |
    When AgentDesktop Solstice Authenticate If Needed
    And Close browser

  @SOLTESAU-28158
  Scenario: Verify AgentDesktop logout functionality
    Given AgentDesktop Solstice Login Application
      | Username              | Password              | Environment                  |
      | AGENTDESKTOP/Username | AGENTDESKTOP/Password | AGENTDESKTOP/testEnvironment |
    And Close browser

  @SOLTESAU-28159
  Scenario: Verify AgentDesktop customer search functionality
    Given AgentDesktop Solstice Login Application
      | Username              | Password              | Environment                  |
      | AGENTDESKTOP/Username | AGENTDESKTOP/Password | AGENTDESKTOP/testEnvironment |
    When AgentDesktop Solstice Search Customer
      | navigateView | searchBy              | customerID   |
      | home         | Solstice Kundennummer | 102000488556 |
    And Close browser

  @SOLTESAU-28160
  Scenario: Verify AgentDesktop Action Bar functionality
    Given AgentDesktop Solstice Login Application
      | Username              | Password              | Environment                  |
      | AGENTDESKTOP/Username | AGENTDESKTOP/Password | AGENTDESKTOP/testEnvironment |
    When AgentDesktop Solstice Search Customer
      | navigateView | searchBy              | customerID   |
      | home         | Solstice Kundennummer | 102000488556 |
    And AgentDesktop Action Bar Click Icon
      | iconClass |
      | fa-edit   |
    And Close browser

  @SOLTESAU-28161
  Scenario: Verify AgentDesktop WriteActionPanel functionality
    Given AgentDesktop Solstice Login Application
      | Username              | Password              | Environment                  |
      | AGENTDESKTOP/Username | AGENTDESKTOP/Password | AGENTDESKTOP/testEnvironment |
    When AgentDesktop Solstice Search Customer
      | navigateView | searchBy              | customerID   |
      | home         | Solstice Kundennummer | 102000488556 |
    And AgentDesktop Action Bar Click Icon
      | iconClass |
      | fa-edit   |
    And AgentDesktop Solstice WriteActionPanel Select Write Action
      | writeActions               |
      | E-Mail-Adresse ?ndern (EM) |
    And Close browser

  @SOLTESAU-28162
  Scenario: Verify Hashicorp  environment connectivity on E2E
    Given Hashicorp  environment connectivity on E2E

  @SOLTESAU-28166
  Scenario: Verify Hashicorp  environment connectivity on SANDBOX
    Given Hashicorp  environment connectivity on SANDBOX

  @SOLTESAU-28163
  Scenario: Verify Hashicorp  environment connectivity on DEV
    Given Hashicorp  environment connectivity on DEV

  @SOLTESAU-28164
  Scenario: Verify Hashicorp  environment connectivity on TEST
    Given Hashicorp  environment connectivity on TEST
