package globalVariables;

/* All the Credentials and URLs which are accessed across all the stages, needs to be declared here */

public class Credentials {
    private static String prodJiraSite = "ALM_JIRA"
    private static String preprodJiraSite = "ALM_JIRA_PRE_PROD"
    private static String prodJiraInstance = ""
    private static String preprodJiraInstance = ""
}
