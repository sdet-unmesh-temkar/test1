package globalVariables

/* All the variables which are accessed across all the stages, needs to be declared here */

class Variables {
    private static String finalExecutionTime = 0
    private static String startDate = ""
    private static String endDate = ""

    private static String jiraID = ""
    private static String jiraInstanceToBeUsed = ""
    private static String logContent = ""

    private static String baseurl = "https://github.vodafone.com"
    private static String headerval = "application/json"
    private static String proxy = "http://proxy.art-int02:3128"
    private static String prversion = ""
    private static String sonarQualityStatus = "True"
    private static HashMap<String,Object> qualityGates = new HashMap<>()

    static String gettingLogContent() {
        return logContent
    }

    static void settingLogContent(String logContent) {
        Variables.logContent = logContent
    }

    static String gettingFinalExecutionTime() {
        return finalExecutionTime
    }

    static void settingFinalExecutionTime(String finalExecutionTime) {
        Variables.finalExecutionTime = finalExecutionTime
    }

    static String gettingStartDate() {
        return startDate
    }

    static void settingStartDate(String startDate) {
        Variables.startDate = startDate
    }

    static String gettingEndDate() {
        return endDate
    }

    static void settingEndDate(String endDate) {
        Variables.endDate = endDate
    }

    static String gettingJiraID() {
        return jiraID
    }

    static void settingJiraID(String jiraID) {
        Variables.jiraID = jiraID
    }

    static String getSonarQualityStatus() {
        return sonarQualityStatus
    }

    static void setSonarQualityStatus(String status) {
        sonarQualityStatus = status
    }

    static String getQualityGates(String key) {
        return qualityGates.get(key)
    }

    static void setQualityGates(String key, Object value) {
        qualityGates.put(key,value)
    }


}
