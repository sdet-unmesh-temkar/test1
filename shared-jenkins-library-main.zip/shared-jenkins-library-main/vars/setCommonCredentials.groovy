import globalVariables.Credentials
import globalVariables.Variables

/**
 * This method has implementation to set Jira Site Credentials as per the prod or preprod environment
 *
 * @byDefault this method will set the parameters of prod environment
 * @param pass string "preprod" as parameter to set the preprod parameters
 * @return none
 */

def call(String site){
    // Set Parameters of Jenkins master
    echo "Jenkins URL"
  	echo "${JENKINS_URL}"
  	echo "Jira Instance is:${env.JIRA_INSTANCE}"

    if(env.JIRA_INSTANCE == null){
        Credentials.prodJiraInstance = "SERVER-a4e7b41d-2208-4538-a1e3-faa7d53fada0"
        Credentials.preprodJiraInstance = "SERVER-3813ed44-8818-445a-9573-6d1bc1e30356"
        Credentials.prodJiraSite = "Prod_Jira"
        Credentials.preprodJiraSite = "Prepod_Jira"
    //Set Parameters of Jcontroller
    }else {
        Credentials.prodJiraInstance = env.JIRA_INSTANCE
        Credentials.preprodJiraInstance = env.PREPROD_JIRA_INSTANCE
        Credentials.prodJiraSite = env.JIRA_SITE
        Credentials.preprodJiraSite = env.PREPROD_JIRA_SITE
    }

    // Condition to set prod or preprod environment variables
    if(site.matches("prod")){
        env.JIRA_SITE = Credentials.prodJiraSite
        Variables.jiraInstanceToBeUsed = Credentials.prodJiraInstance
        echo "Jira Instance tobe used on prod"
        echo "${Variables.jiraInstanceToBeUsed}"
    }
    else if(site.matches("preprod")){
        env.JIRA_SITE = Credentials.preprodJiraSite
        Variables.jiraInstanceToBeUsed = Credentials.preprodJiraInstance
        echo "Jira Instance tobe used on preprod"
        echo "${Variables.jiraInstanceToBeUsed}"
    }

}

// This method is overloaded to set the prod environment variables when no parameter is passed
def call(){
    call("prod")
}
