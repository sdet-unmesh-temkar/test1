def call(){
    echo "${FromBranch}"
    echo "${ToBranch}"
    echo "${PRID}"    
    echo "${eventKey}"    
}
