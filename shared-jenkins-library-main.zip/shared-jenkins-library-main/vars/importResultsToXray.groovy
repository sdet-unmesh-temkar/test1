import globalVariables.Variables

/**
 * Description :- This step will create a test execution and will import the results
 *                 to xray by reading cucumber.json file.
 *
 * @param projectKey - It is the projectKey
 * @param EnvironmentName - It is the environment name on which tests needs to be executed
 * @param testPlan - It is the testPlan ID to which Test Executions needs to be linked
 * @param labelForXray - These are Labels which are updated to Jira
 * @return None
 */

def call(String projectKey, String environmentName, String testPlan, String labelForXray) {

    def importInfo = ''

    script {
        def testExecutionInfo = [
                fields: [:]
        ]

        /*
        Adding fields project,description,summary,etc. to testExecutionInfo JSON object
         */
        testExecutionInfo.fields.project = [key: projectKey]
        testExecutionInfo.fields.description = "Execution results imported from build URL - ${BUILD_URL} \n Last Commit -  ${GIT_COMMIT} \n Test Execution Time - ${Variables.gettingFinalExecutionTime()}"
        testExecutionInfo.fields.summary = "Result by Jenkins Job - ${JOB_NAME} and build ${BUILD_ID}"
        testExecutionInfo.fields.issuetype = [id: "10415"]
        testExecutionInfo.fields.assignee = [name: "9StefanHackenberg.SJIRAAWSJenkinsVG0976YR@vodafone.com"]
        testExecutionInfo.fields.customfield_10465 = ["${environmentName}"]//customfield_10465: represents environment field
        testExecutionInfo.fields.customfield_10457 = Variables.gettingStartDate()
        testExecutionInfo.fields.customfield_10458 = Variables.gettingEndDate()

        /*
        Add testPlan to testExecutionInfo JSON object if provided by the user
         */
        if (!testPlan.isBlank())
            testExecutionInfo.fields.customfield_10467 = ["${testPlan}"]//customfield_10467: represents testPlan field
        /*
        Add labels array to testExecutionInfo JSON object if provided the by user
        */
        if (!labelForXray.isBlank())
            testExecutionInfo.fields.labels = labelForXray.split(",")

        /*
        Convert testExecutionInfo JSON object to JSON string and store it in 'importInfo'
         */
        importInfo = groovy.json.JsonOutput.toJson(testExecutionInfo)
    }

    step([$class: 'XrayImportBuilder', endpointName: '/cucumber/multipart', importFilePath: "\\target\\cucumber.json", importInfo: "${importInfo}", inputInfoSwitcher: 'fileContent', serverInstance: "${Variables.jiraInstanceToBeUsed}"])

    script {
        // Reading jenkins console for fetching test execution ID
        def logContent = Jenkins.getInstance().getItemByFullName("${JOB_NAME}").getBuildByNumber(Integer.parseInt("${BUILD_NUMBER}")).logFile.text
        def xrayStartIndex = logContent.indexOf("XRAY_TEST_EXECS")
        Variables.settingLogContent(logContent)

        // Fetching JiraID from console logs
        Variables.settingJiraID(logContent.substring(logContent.indexOf("XRAY_TEST_EXECS") + 17, logContent.indexOf("XRAY_TEST_EXECS") + logContent.substring(xrayStartIndex).indexOf("\n")));

        //Fetching transitionID to update execution status to done
        def responseData = jiraGetIssueTransitions idOrKey: "${Variables.gettingJiraID()}"
        def transitionID = " "
        for (def array : responseData.data.transitions) {
            if (array.name == 'Done') {
                transitionID = array.id
                break
            }
        }

        //Making test execution status to done
        def transitionInput = [transition: [id: "${transitionID}"], fields: [resolution: ['name': 'Done']]]
        def response = jiraTransitionIssue idOrKey: "${Variables.gettingJiraID()}", input: transitionInput
        if (response.successful.toString()) {
            println "Jira Transition has been updated successfully."
        }
    }
}