/**
 * ***THIS METHOD/STAGE WILL BE REMOVED AFTER ALL APPLICATION TEAMS MIGRATE TO JCONTROLLER *****
 *
 * Description:- STAF requires jdk 11 for successful execution.
 *               This stage will set the jdk path based on the slave name passed from the jenkins job.
 *
 * @param jenkinsAgentLabelName - its the jenkins agent name / slave name
 * @return the Java Home path for passed jenkins agent
 */

def call(String jenkinsAgentLabelName) {
    if (jenkinsAgentLabelName.matches("solstice-art-int02-windows-slave|solstice_xtest02_windows_slave")) {
        env.JAVA_HOME = "C:/Program Files/Java/jdk-11"
    }
    else if (jenkinsAgentLabelName.matches("solstice_art-int01_slave")) {
        env.JAVA_HOME = "/usr/lib/jvm/java-11-openjdk-11.0.16.0.8-1.amzn2.0.1.x86_64/"
    }
    else if (jenkinsAgentLabelName.matches("solstice_art-int02_slave")) {
        env.JAVA_HOME = "/usr/lib/jvm/java-11-amazon-corretto.x86_64"
    }
    else if (jenkinsAgentLabelName.matches("solstice_art-int03_slave")) {
        env.JAVA_HOME = "/usr/lib/jvm/java-11-amazon-corretto.x86_64/"
    }
    else if (jenkinsAgentLabelName.matches("solstice_xtest03_slave")) {
        env.JAVA_HOME = "/usr/lib/jvm/java-11-openjdk-11.0.19.0.7-1.amzn2.0.1.x86_64/"
    }
    else if (jenkinsAgentLabelName.matches("solstice_xtest02_slave")) {
        env.JAVA_HOME = "/usr/lib/jvm/java-11-openjdk-11.0.13.0.8-1.amzn2.0.3.x86_64/"
    }
    else if (jenkinsAgentLabelName.matches("solstice_mig01_slave")) {
        //env.JAVA_HOME = "/usr/lib/jvm/java-11-openjdk-11.0.15.0.9-2.el7_9.x86_64/"
      env.JAVA_HOME = "/usr/lib/jvm/java-11-openjdk-11.0.19.0.7-1.el7_9.x86_64/"
    }
    else if (jenkinsAgentLabelName.matches("cimcdhdev")) {
        env.JAVA_HOME = "/usr/lib/jvm/java-11-openjdk/"
    }
    else if(jenkinsAgentLabelName.matches("cimcdhogg")){
        env.JAVA_HOME = "/usr/lib/jvm/java-11-openjdk-11.0.16.0.8-1.el8_6.x86_64"
    }
    else if (jenkinsAgentLabelName.matches("cimcdhogg2")) {
        env.JAVA_HOME = "/usr/lib/jvm/java-11-openjdk-11.0.16.1.1-1.el8_6.x86_64"
    }
    else if (jenkinsAgentLabelName.matches("cimcdhxtest14")) {
      env.JAVA_HOME = "/usr/lib/jvm/jre-11-openjdk-11.0.18.0.10-2.el8_7.x86_64/"
    }
    else if (jenkinsAgentLabelName.matches("cimcdhartint04")) {
        env.JAVA_HOME = "/usr/lib/jvm/jre-11-openjdk-11.0.18.0.10-2.el8_7.x86_64/"
    }
}
