import globalVariables.Variables

import javax.swing.plaf.metal.MetalFileChooserUI
import java.text.SimpleDateFormat;

/**
 * Description:- This stage will build STAF and execute the test cases based on
 *               the tag name from Jenkins Job.
 *               Also execution time is being calculated in this stage.
 *
 * @param testType - its the TestTag that needs to be executed
 * @param environmentName - environment name on which tests needs to be executed
 * @param isParallelExecute - to define whether test execution will be parallel or not
 * @param TypeOfParallelExecution - to define the which parallel execution profile will be used
 * @param threadOrForkCount - to define the thread's or fork's count for parallel execution
 *
 */

def call(String testType, String environmentName, String isParallelExecute, String typeOfParallelExecution, String threadOrForkCount) {
    // To record start Date & Time of Execution
    SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
    Date date1 = format.parse("${new Date().format('HH:mm:ss')}");
    Date dateStart = new Date();
    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SZ");
    Variables.settingStartDate(formatter.format(dateStart));

    String cmdMvnUnix = "mvn clean install -Dmaven.exec.skip=true -DskipTests -Dmaven.wagon.http.ssl.insecure=true -T 10 && mvn clean test -Dmaven.wagon.http.ssl.insecure=true -Dcucumber.filter.tags='${testType}' -Denv='${environmentName}' -DheadlessBrowser";
    String cmdMvnWindows = "mvn clean install -Dmaven.exec.skip=true -DskipTests -Dmaven.wagon.http.ssl.insecure=true -T 10 && mvn clean test -Dmaven.wagon.http.ssl.insecure=true -Dcucumber.filter.tags=\"%testType%\" -Denv=\"%environmentName%\"";

    try {
        withCredentials([usernamePassword(credentialsId: 'Vault_ROLEID', passwordVariable: 'Vault_ROLEID_PSW', usernameVariable: 'Vault_ROLEID_USR')]) {
            withCredentials([usernamePassword(credentialsId: 'Vault_SECRETID', passwordVariable: 'Vault_SECRETID_PSW', usernameVariable: 'Vault_SECRETID_USR')]) {

                // Formation of shell command to run the testcase on Linux machine
                if (isUnix()){
                    String cmdMvnUnixWithVault = cmdMvnUnix + " -DVault_ROLEID='${Vault_ROLEID_PSW}' -DVault_SECRETID='${Vault_SECRETID_PSW}'"
                    if (isParallelExecute.equalsIgnoreCase("NO")) {
                        echo "Sequential Execution With Vault Credential on Linux Jenkins Slave"
                        sh cmdMvnUnixWithVault
                    }else {
                        switch (typeOfParallelExecution){
                            case "Scenarios Parallel":
                                echo "Scenario Parallel Execution With Vault Credential on Linux Jenkins Slave"
                                sh cmdMvnUnixWithVault + " -PscenariosParallel -DthreadCount='${threadOrForkCount}' "
                                break;
                            case "Multi Forking":
                                echo "Multi Forking Execution With Vault Credential on Linux Jenkins Slave"
                                sh cmdMvnUnixWithVault + " -DforkCount='${threadOrForkCount}' "
                                break;
                            default:
                                echo "Features Parallel Execution With Vault Credential on Linux Jenkins Slave"
                                sh cmdMvnUnixWithVault + " -PfeaturesParallel -DthreadCount='${threadOrForkCount}' "
                                break;
                        }
                    }
                }else {
                    String cmdMvnWindowsWithVault = cmdMvnWindows + " -DVault_ROLEID=\"%Vault_ROLEID_PSW%\" -DVault_SECRETID=\"%Vault_SECRETID_PSW%\""
                    if (isParallelExecute.equalsIgnoreCase("NO")) {
                        echo "Sequential Execution With Vault Credential on Windows Jenkins Slave"
                        bat label: '', script: cmdMvnWindowsWithVault
                    }else {
                        switch (typeOfParallelExecution) {
                            case "Scenarios Parallel":
                                echo "Scenario Parallel Execution With Vault Credential on Windows Jenkins Slave"
                                bat label: '', script:  cmdMvnWindowsWithVault + " -PscenariosParallel -DthreadCount=\"%threadOrForkCount%\" "
                                break;
                            case "Multi Forking":
                                echo "Multi Forking Execution With Vault Credential on Windows Jenkins Slave"
                                bat label: '', script: cmdMvnWindowsWithVault + " -DforkCount=\"%threadOrForkCount%\" "
                                break;
                            default:
                                echo "Features Parallel Execution With Vault Credential on Windows Jenkins Slave"
                                bat label: '', script: cmdMvnWindowsWithVault + " -PfeaturesParallel -DthreadCount=\"%threadOrForkCount%\" "
                                break;
                        }
                    }
                }
            }
        }
    }catch(IOException exp) {
        if(exp.getMessage().toString().contains("Could not find credentials entry with ID 'Vault_")) {
            echo "${exp.getMessage()}, SO TESTS WILL BE EXECUTED WITHOUT USING Vault_ROLEID and Vault_SECRETID VALUES."
            // Formation of shell command to run the testcase on Linux machine
            if (isUnix()) {
                if (isParallelExecute.equalsIgnoreCase("NO")) {
                    echo "Sequential Execution Without Vault Credential on Linux Jenkins Slave"
                    sh cmdMvnUnix
                }else {
                    switch (typeOfParallelExecution) {
                        case "Scenarios Parallel":
                            echo "Scenario Parallel Execution Without Vault Credential on Linux Jenkins Slave"
                            sh cmdMvnUnix + " -PscenariosParallel -DthreadCount='${threadOrForkCount}' "
                            break;
                        case "Multi Forking":
                            echo "Multi Forking Execution Without Vault Credential on Linux Jenkins Slave"
                            sh cmdMvnUnix + " -DforkCount='${threadOrForkCount}' "
                            break;
                        default:
                            echo "Features Parallel Execution Without Vault Credential on Linux Jenkins Slave"
                            sh cmdMvnUnix + " -PfeaturesParallel -DthreadCount='${threadOrForkCount}' "
                            break;
                    }
                }
            }else {
                if (isParallelExecute.equalsIgnoreCase("NO")) {
                    echo "Sequential Execution Without Vault Credential on Windows Jenkins Slave"
                    bat label: '', script: cmdMvnWindows
                } else {
                    switch (typeOfParallelExecution) {
                        case "Scenarios Parallel":
                            echo "Scenario Parallel Execution Without Vault Credential on Windows Jenkins Slave"
                            bat label: '', script: cmdMvnWindows + " -PscenariosParallel -DthreadCount=\"%threadOrForkCount%\" "
                            break;
                        case "Multi Forking":
                            echo "Multi Forking Execution Without Vault Credential on Windows Jenkins Slave"
                            bat label: '', script: cmdMvnWindows + " -DforkCount=\"%threadOrForkCount%\" "
                            break;
                        default:
                            echo "Features Parallel Execution Without Vault Credential on Windows Jenkins Slave"
                            bat label: '', script: cmdMvnWindows + " -PfeaturesParallel -DthreadCount=\"%threadOrForkCount%\" "
                            break;
                    }
                }
            }
        }
    }


    // To record End Date & Time of Execution
    Date date2 = format.parse("${new Date().format('HH:mm:ss')}");
    def tookTime = date2.getTime() - date1.getTime()
    Date dateEnd = new Date();
    Variables.settingEndDate(formatter.format(dateEnd));

    // Calculating final execution time
    long seconds = (long) (tookTime / 1000);
    if (seconds > 60) {
        long minutes = (long) (seconds / 60);
        seconds = seconds % 60;
        if (minutes > 60) {
            long hours = (long) (minutes / 60);
            minutes = minutes % 60;
            if (hours > 24) {
                long days = (long) (hours / 24);
                finalExecutionTime = "${days}d"

            } else
                Variables.settingFinalExecutionTime("${hours}h${minutes}m")

        } else
            Variables.settingFinalExecutionTime("${minutes}m${seconds}s")

    } else
        Variables.settingFinalExecutionTime("${seconds}s")


}

// method overloading to pass isParallelExecute,typeOfParallelExecution and threadOrForkCount default value
def call(String testType, String environmentName) {
    call(testType, environmentName,"NO", "Features Parallel", "1")
}

