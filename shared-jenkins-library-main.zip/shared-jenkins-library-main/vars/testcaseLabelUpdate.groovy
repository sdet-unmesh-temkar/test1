import globalVariables.Credentials

/**
 * Description :- This stage will add all the tags which are above the test case in feature file
 *                as a label to jira test
 *
 * @param projectKey - It is the projectKey
 * @return None
 */

def call(String projectKey){
    def list = [] as String[]
    def testCaseItem
    def projects = readJSON file: "\\target\\cucumber.json" , returnPojo: true
    def keyList = projects['elements'] ['tags']
    def pattern = "@[SOL][A-Z]{2,}-\\d+";
    keyList.each {
        it.each{
            list = []
            testCaseItem = null;
            it.each{
                it.each{
                    k,v ->
                        if(v=~pattern)
                            testCaseItem=v.replaceAll("@","")
                        if(!(v=~pattern))
                            list << (v.replaceAll("@","").replaceAll(" ",""))
                }
            }
            list.findAll {it.trim()!= '' }
            echo "Labels:${list} Testcase: ${testCaseItem}"
            if(testCaseItem != null){
                def testIssue1 = [fields:[        
                        labels: list
                ]
                ]
                response = jiraEditIssue idOrKey: testCaseItem, issue: testIssue1, site: "${Credentials.prodJiraSite}"
                echo response.successful.toString()
                echo response.data.toString()
            }
        }
    }
}

