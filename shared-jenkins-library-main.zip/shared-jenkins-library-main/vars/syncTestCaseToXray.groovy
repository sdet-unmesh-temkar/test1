import globalVariables.Variables

/**
 * Description :- This step will sync a existing test case into xray
 *                 and create new test cases in xray if flag is true. *
 * @param projectKey - It is the projectKey
 * @param flag       - This flag is used to decide whether new test cases need to create in xray or not
 */

def call(String projectKey,boolean flag){

    File dirExisting = new File("${workspace}/target/scenarios/existing")
    if (dirExisting.exists()) {
    step([$class: 'XrayImportFeatureBuilder', folderPath: "target/scenarios/existing", lastModified: '', projectKey: "${projectKey}", serverInstance: "${Variables.jiraInstanceToBeUsed}"])
    }
    else{
        println('no existing test cases found to sync in xray')
    }
    
    
    if(flag){
        File dirNew = new File("${workspace}/target/scenarios/new")
        if (dirNew.exists()) {
        step([$class: 'XrayImportFeatureBuilder', folderPath: "target/scenarios/new", lastModified: '', projectKey: "${projectKey}", serverInstance: "${Variables.jiraInstanceToBeUsed}"])
        }
        else{
             println('no new test cases found to sync in xray')
        }
    }
}

/**
 * Description :- This step will sync a existing test case into xray
 *                 and keep default flag as false so that new test cases should not created in xray
 */
def call(String projectKey){
    call(projectKey,false)
}
