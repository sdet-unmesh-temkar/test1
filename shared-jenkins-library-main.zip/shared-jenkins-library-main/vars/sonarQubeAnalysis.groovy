import globalVariables.Variables
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def bugcount = ""
def codesmells = ""
def vulnerabilitycount = ""
def duplicateBlockscount = ""
def qualityStatus = "True"
def sonarAuth = ""
def sonarURL = ""

def call(int bugCount, int codeSmells, int vulnerabilitycount,double duplicateBlockscount,String pipelineTerminateFlag) {
    withSonarQubeEnv(credentialsId: 'cicd-sonarqube-atjc-token', installationName: 'sonarqube_enterprise') {
        withCredentials([gitUsernamePassword(credentialsId: 'githubapp_STAF', gitToolName: 'git')]) {
            sh '''
               git ls-remote origin pull/*/head | awk '{print $2}' |
               while read line; do
               if echo "$line" | grep -q "${PRID}"; then
               echo $line
               git fetch origin $line > /dev/null
               git checkout FETCH_HEAD
               git switch -c tempMerging
               git checkout testing
               git pull             
               git merge tempMerging > mergestatus.txt
               mvn clean install sonar:sonar -Dsonar.projectKey=vfde-solstice-staf-utilities -Dsonar.projectName='vfde-solstice-staf-utilities' -Dmaven.exec.skip=true -DskipTests -Dmaven.wagon.http.ssl.insecure=true -T 10
               fi
               done
           '''
        }
        sleep(time: 3, unit: "SECONDS")

        sonarAuth = "${env.SONAR_AUTH_TOKEN}"
        sonarURL = "${env.SONAR_HOST_URL}"
    }


    script {
        def response = sh(script: "curl -X GET -u ${sonarAuth} '${sonarURL}/api/issues/search?componentKeys=vfde-solstice-staf-utilities&resolved=false&types=BUG&id=vfde-solstice-staf-utilities'", returnStdout: true).trim()
        def jsonSlurper = new JsonSlurper()
        def jsonObject = jsonSlurper.parseText("${response}")
        Variables.setQualityGates("bugcount",jsonObject.total)
        echo "Bugs Count : ${Variables.getQualityGates("bugcount")}"
    }

    script {
        def response = sh(script: "curl -X GET -u ${sonarAuth} '${sonarURL}/api/issues/search?componentKeys=vfde-solstice-staf-utilities&resolved=false&types=CODE_SMELL&id=vfde-solstice-staf-utilities'", returnStdout: true).trim()
        def jsonSlurper = new JsonSlurper()
        def jsonObject = jsonSlurper.parseText("${response}")
        Variables.setQualityGates("codesmells",jsonObject.total)
        echo "Code Smells Count : ${Variables.getQualityGates("codesmells")}"
    }

    script {
        def response = sh(script: "curl -X GET -u ${sonarAuth} '${sonarURL}/api/issues/search?componentKeys=vfde-solstice-staf-utilities&resolved=false&types=VULNERABILITY&id=vfde-solstice-staf-utilities'", returnStdout: true).trim()
        def jsonSlurper = new JsonSlurper()
        def jsonObject = jsonSlurper.parseText("${response}")
        Variables.setQualityGates("vulnerabilitycount",jsonObject.total)
        echo "Vulnerability Count : ${Variables.getQualityGates("vulnerabilitycount")}"
    }

    script{
//      Use below curl to check for new duplicate code blocks
//         def response = sh(script: "curl -X GET -u ${sonarAuth} '${sonarURL}/api/measures/component?component=vfde-solstice-staf-utilities&metricKeys=new_duplicated_lines_density'", returnStdout: true).trim()
//      Use below curl to check for overall duplicate code blocks
        def response = sh(script: "curl -X GET -u ${sonarAuth} '${sonarURL}/api/measures/component?component=vfde-solstice-staf-utilities&metricKeys=duplicated_lines_density'", returnStdout: true).trim()
        def jsonSlurper = new JsonSlurper()
        def jsonObject = jsonSlurper.parseText("${response}")
        Variables.setQualityGates("duplicateBlockscount",jsonObject.component.measures.value.get(0))
        echo "Duplicate Blocks Percentage : ${Variables.getQualityGates("duplicateBlockscount")}%"
    }


    if (Variables.getQualityGates("bugcount") > bugCount || Variables.getQualityGates("codesmells") > codeSmells || Variables.getQualityGates("vulnerabilitycount") > vulnerabilitycount || Double.valueOf(Variables.getQualityGates("duplicateBlockscount")) > duplicateBlockscount) {
        Variables.setSonarQualityStatus("False")
        if (pipelineTerminateFlag == "True") {
            error "Pipeline aborted due to quality gate failure, Bug count :${Variables.getQualityGates("bugcount")}, Code Smells : ${Variables.getQualityGates("codesmells")}, Vulnerability : ${Variables.getQualityGates("vulnerabilitycount")}, Duplicateblocks : ${Variables.getQualityGates("duplicateBlockscount")}"
        }

    }
}

// method overloading to pass default value
def call(){
    call(0,0,0,0.0,"True")
}