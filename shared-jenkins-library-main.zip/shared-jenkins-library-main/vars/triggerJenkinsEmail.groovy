import globalVariables.Variables

/**
 * Description :- This stage will trigger the mail with execution details and graphs
 *                 to the mail address mentioned in Jenkins parameters
 *
 * @param EmailID - It is EmailID to which mail will be triggered with execution details
 * @return None
 */



def call(String EmailID) {

        if (EmailID != '') {
            try {
                String attachFile = ""
                if (fileExists('target/ExtentReport/IntegratedReport/ExtentReportZip.zip')) {
                    attachFile = "target/reportFiles/pieChart.jpeg,target/ExtentReport/IntegratedReport/ExtentReportZip.zip"
                } else {
                    attachFile = "target/reportFiles/pieChart.jpeg,target/ExtentReport/IntegratedReport/ExtentReport.html"
                }
                echo "${attachFile}"

                emailext from: 'staf.jenkins@vodafone.com', attachmentsPattern: "target/reportFiles/pieChart.jpeg,${attachFile}",
                        body: "<br><b>Build Number:</b> ${env.BUILD_NUMBER}<br>" +
                  				"<b>Environment Name:</b> ${EnvironmentName}<br>"+ 
                  				"<b>Execution Time:</b> ${Variables.gettingFinalExecutionTime()}<br>"+                 				
                  				"<b>Jenkins Job Name:</b> ${env.JOB_NAME}<br>" +
                                "<b>Build URL:</b> ${env.BUILD_URL}<br>" +
                  				"<b>Xray Test Execution:</b> https://de.jira.agile.vodafone.com/browse/" + Variables.gettingJiraID() + "<br>" +
                                "<html>" +
                                "<body>" +
                                "<table>" +
                                "<td style=\"border: none;\">" + readFile("target/reportFiles/summary.html") + "</td>" +
                                "<td style=\"border: none;\"><img src='cid:pieChart.jpeg' align=\"left\"></td>" +
                                "</table>" +
                                "</body>" +
                                "</html>" +
                                readFile("target/reportFiles/testCaseDetails.html"),
                        mimeType: 'text/html',
                        subject: "Jenkins job Notification for build-> ${env.JOB_NAME}",
                        to: "${EmailID}"
            } catch (Exception e) {
                echo "Email not sent :" + e
            }

        }
    }
