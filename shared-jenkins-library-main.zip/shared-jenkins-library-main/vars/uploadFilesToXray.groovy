import groovy.io.FileType;
import static groovy.io.FileType.FILES;
import globalVariables.Variables;

def call(String pathOfFiles){
    String workspace = "${WORKSPACE}"
    echo "${workspace}"
    String finalWorkspace = workspace.replace("\\","/")
    echo "Final Workspace: "+ finalWorkspace
    def fileArray = pathOfFiles.split(",")
    fileArray.each {
        echo "Path of files :" + it
        def files = findFiles(glob: it)
        echo "${files}"
        files.each {
            def element = it
            echo "${finalWorkspace}/${element}"
            def attachment = jiraUploadAttachment idOrKey: Variables.gettingJiraID(), file: "${finalWorkspace}/${element}"
        }
    }
}




