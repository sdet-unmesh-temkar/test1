/**
 * Description:- STAF requires jdk 11 for successful execution.
 *               This stage will store the Jenkins Config file under default location ${env.HOME/.m2 folder or user provided targetLocation
 *
 * @param fileId - its the id of Jenkins Config file
 * @param targetLocation - its the location where Jenkins Config file need to be stored
 * @return none
 */

def call(String fileId, String targetLocation) {
    configFileProvider([configFile(fileId: fileId, targetLocation: targetLocation)]) {}
}

// method overloading to pass targetLocation default value
def call(String fileId) {
    call(fileId,"${env.HOME}/.m2")
}
