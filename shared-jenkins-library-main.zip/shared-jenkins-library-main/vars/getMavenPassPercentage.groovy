import globalVariables.Variables
import java.text.SimpleDateFormat;

/**
 * Description:- This stage will find Maven Passed or Failed Percentage
 *
 * @param TestType - its the TestTag that needs to be executed
 * @return None
 */

def int call()
{
    String[] percentageValue
    def mavenSummaryReoprt = readFile "target/reportFiles/summary.html"
    def parsedResponse = new XmlSlurper().parseText(mavenSummaryReoprt)

    def failedValues= parsedResponse.'**'.findAll { tr -> tr.td.text().contains('Failed')}
    for (groovy.util.slurpersupport.NodeChild failedValue : failedValues)
    {
        println("Failed Test cases count :- ${failedValue.children()[1]}")
        println("Maven build failed percentage :- ${failedValue.children()[2]}")
    }

    def passedValues= parsedResponse.'**'.findAll { tr -> tr.td.text().contains('Passed')}
    for (groovy.util.slurpersupport.NodeChild passedValue : passedValues)
    {
        String passedPercentage=passedValue.children()[2]
        println("Passed Test cases count :- ${passedValue.children()[1]}")
        println("Maven build passed percentage :- ${passedValue.children()[2]}")
        percentageValue =passedPercentage.split('%')
    }

    return percentageValue[0] as int
}


